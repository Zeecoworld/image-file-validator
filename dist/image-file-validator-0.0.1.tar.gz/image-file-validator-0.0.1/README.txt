This is a simple pluggable python library that validate image file and size useful for all 
type of python applications.