from image_file_validator.image_file_validator import check_file_type



#TESTING THE PYTHON PACKAGE

checking_for_mime = check_file_type("./hh.png")


print(checking_for_mime)